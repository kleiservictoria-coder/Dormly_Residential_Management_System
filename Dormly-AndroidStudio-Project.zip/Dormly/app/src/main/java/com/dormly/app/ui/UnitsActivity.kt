package com.dormly.app.ui

import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import com.dormly.app.R
import com.dormly.app.data.HousingUnit
import com.dormly.app.data.Options
import com.dormly.app.data.Role
import com.dormly.app.util.SimpleAdapter
import com.dormly.app.util.UiUtil
import com.dormly.app.util.bind

/** Admin screen: list, add and remove housing units. Residents are assigned from the Residents screen. */
class UnitsActivity : BaseActivity() {

    override val allowedRoles = arrayOf(Role.ADMIN)

    private lateinit var adapter: SimpleAdapter<HousingUnit>
    private lateinit var txtEmpty: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!authorized) return
        setContentView(R.layout.activity_simple_list)
        setupToolbar("Housing Units", "+ Add") { showAddDialog() }

        txtEmpty = bind(R.id.txtEmpty)
        txtEmpty.text = "No housing units yet. Tap + Add to create one."

        adapter = SimpleAdapter(this, R.layout.item_unit) { v, u ->
            v.bind<TextView>(R.id.txtUnitNumber).text = "Unit ${u.number}"
            v.bind<TextView>(R.id.txtUnitInfo).text = "Floor ${u.floor} \u00B7 ${u.type}"
            v.bind<TextView>(R.id.txtOccupants).text =
                if (u.residentCount == 0) "No residents" else u.residentNames
            val chip = v.bind<TextView>(R.id.txtOccupancy)
            if (u.residentCount == 0) UiUtil.styleChip(chip, "Vacant", getColor(R.color.status_pending))
            else UiUtil.styleChip(chip, "Occupied", getColor(R.color.status_completed))
        }
        val list = bind<ListView>(R.id.listView)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, position, _ -> showUnitDialog(adapter.getItem(position)) }
    }

    override fun onResume() {
        super.onResume()
        if (!authorized) return
        load()
    }

    private fun load() {
        val units = db.getUnits()
        adapter.setItems(units)
        txtEmpty.visibility = if (units.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun showUnitDialog(unit: HousingUnit) {
        val details = "Floor ${unit.floor} \u00B7 ${unit.type}\n\n" +
            if (unit.residentCount == 0) "This unit is vacant." else "Residents: ${unit.residentNames}"
        val builder = AlertDialog.Builder(this)
            .setTitle("Unit ${unit.number}")
            .setMessage(details)
            .setPositiveButton("Close", null)
        if (unit.residentCount == 0) {
            builder.setNeutralButton("Delete unit") { _, _ ->
                AlertDialog.Builder(this)
                    .setTitle("Delete Unit ${unit.number}?")
                    .setPositiveButton("Delete") { _, _ ->
                        db.deleteUnit(unit.id)
                        toast("Unit deleted")
                        load()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        } else {
            builder.setMessage(details + "\n\nMove residents to another unit (Residents screen) before deleting this unit.")
        }
        builder.show()
    }

    private fun showAddDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_unit, null)
        val etNumber = view.bind<EditText>(R.id.etUnitNumber)
        val etFloor = view.bind<EditText>(R.id.etFloor)
        val spType = view.bind<Spinner>(R.id.spType)
        spType.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, Options.UNIT_TYPES).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("Add housing unit")
            .setView(view)
            .setPositiveButton("Add", null)
            .setNegativeButton("Cancel", null)
            .create()
        dialog.show()
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val number = etNumber.text.toString().trim()
            val floor = etFloor.text.toString().trim()
            if (number.isEmpty()) { etNumber.error = "Unit number is required"; return@setOnClickListener }
            if (floor.isEmpty()) { etFloor.error = "Floor is required"; return@setOnClickListener }
            val id = db.addUnit(number, floor, Options.UNIT_TYPES[spType.selectedItemPosition])
            if (id < 0) { etNumber.error = "This unit already exists"; return@setOnClickListener }
            dialog.dismiss()
            toast("Unit $number added")
            load()
        }
    }
}
