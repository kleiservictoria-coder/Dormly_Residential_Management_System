package com.dormly.app.util

import android.content.Context
import com.dormly.app.data.DormlyDb
import com.dormly.app.data.User

/** Remembers the signed-in user (by id) across app restarts. */
object Session {
    private const val PREFS = "dormly_session"
    private const val KEY_USER = "user_id"

    fun login(context: Context, user: User) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putLong(KEY_USER, user.id).apply()
    }

    fun logout(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_USER).apply()
    }

    fun currentUser(context: Context): User? {
        val id = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY_USER, -1L)
        if (id < 0) return null
        return DormlyDb.get(context).getUser(id)
    }
}
