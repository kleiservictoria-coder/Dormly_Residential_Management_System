package com.dormly.app.ui

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import com.dormly.app.R
import com.dormly.app.data.MaintenanceRequest
import com.dormly.app.data.Role
import com.dormly.app.data.Status
import com.dormly.app.data.User
import com.dormly.app.util.Nav
import com.dormly.app.util.UiUtil
import com.dormly.app.util.bind

/**
 * Request details + status history.
 *  - Admin can assign/reassign the request to maintenance staff.
 *  - Maintenance (when assigned) can update the status and add remarks.
 *  - Resident can only view.
 */
class RequestDetailActivity : BaseActivity() {

    private var requestId = -1L
    private var staff: List<User> = emptyList()
    private var formsReady = false

    private lateinit var cardAssign: View
    private lateinit var cardUpdate: View
    private lateinit var spStaff: Spinner
    private lateinit var spStatus: Spinner
    private lateinit var etAssignNote: EditText
    private lateinit var etRemarks: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!authorized) return
        setContentView(R.layout.activity_request_detail)

        requestId = intent.getLongExtra(Nav.EXTRA_REQUEST_ID, -1L)
        setupToolbar("Request #$requestId")

        cardAssign = bind(R.id.cardAssign)
        cardUpdate = bind(R.id.cardUpdate)
        spStaff = bind(R.id.spStaff)
        spStatus = bind(R.id.spStatus)
        etAssignNote = bind(R.id.etAssignNote)
        etRemarks = bind(R.id.etRemarks)

        bind<Button>(R.id.btnAssign).setOnClickListener { assign() }
        bind<Button>(R.id.btnUpdate).setOnClickListener { updateStatus() }
    }

    override fun onResume() {
        super.onResume()
        if (!authorized) return
        reload()
    }

    private fun canView(r: MaintenanceRequest): Boolean = when (user.role) {
        Role.ADMIN -> true
        Role.RESIDENT -> r.residentId == user.id
        else -> r.assignedToId == user.id
    }

    private fun reload() {
        val r = db.getRequest(requestId)
        if (r == null || !canView(r)) {
            toast("This request is not available.")
            finish()
            return
        }

        bind<TextView>(R.id.txtTitle).text = r.title
        UiUtil.styleStatus(bind(R.id.txtStatus), r.status)
        bind<TextView>(R.id.txtMeta).text = "${r.category} \u00B7 ${r.priority} priority"
        bind<TextView>(R.id.txtDescription).text = r.description
        bind<TextView>(R.id.txtResident).text = r.residentName
        bind<TextView>(R.id.txtUnit).text = r.unitNumber?.let { "Unit $it" } ?: "No unit"
        bind<TextView>(R.id.txtSubmitted).text = UiUtil.formatDate(r.createdAt)
        bind<TextView>(R.id.txtAssigned).text = r.assignedToName ?: "Not assigned yet"

        val open = r.status != Status.COMPLETED

        // ---- admin: assign / reassign
        val showAssign = user.role == Role.ADMIN && open
        cardAssign.visibility = if (showAssign) View.VISIBLE else View.GONE
        if (showAssign) {
            if (staff.isEmpty()) {
                staff = db.getUsersByRole(Role.MAINTENANCE)
                val names = staff.map { it.name }
                spStaff.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, names).also {
                    it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                }
            }
            val idx = staff.indexOfFirst { it.id == r.assignedToId }
            if (idx >= 0) spStaff.setSelection(idx)
            bind<Button>(R.id.btnAssign).text = if (r.assignedToId == null) "Assign request" else "Reassign request"
        }

        // ---- maintenance: update status
        val showUpdate = user.role == Role.MAINTENANCE && r.assignedToId == user.id && open
        cardUpdate.visibility = if (showUpdate) View.VISIBLE else View.GONE
        if (showUpdate) {
            if (!formsReady) {
                spStatus.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, Status.MAINTENANCE_OPTIONS).also {
                    it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                }
                formsReady = true
            }
            val idx = Status.MAINTENANCE_OPTIONS.indexOf(r.status)
            spStatus.setSelection(if (idx >= 0) idx else 0)
        }

        // ---- history timeline
        val box = bind<LinearLayout>(R.id.listHistory)
        box.removeAllViews()
        val history = db.getHistory(r.id)
        for ((i, h) in history.withIndex()) {
            val row = layoutInflater.inflate(R.layout.item_history, box, false)
            val color = UiUtil.statusColor(this, h.status)
            val dot = android.graphics.drawable.GradientDrawable()
            dot.setShape(android.graphics.drawable.GradientDrawable.OVAL)
            dot.setColor(color)
            row.bind<View>(R.id.dot).background = dot
            // hide the connector below the last (oldest) entry
            if (i == history.size - 1) row.bind<View>(R.id.line).visibility = View.INVISIBLE
            val st = row.bind<TextView>(R.id.txtHStatus)
            st.text = h.status
            st.setTextColor(color)
            val remarks = row.bind<TextView>(R.id.txtHRemarks)
            if (h.remarks.isBlank()) remarks.visibility = View.GONE else remarks.text = h.remarks
            row.bind<TextView>(R.id.txtHMeta).text = "${h.updatedByName} \u00B7 ${UiUtil.formatDate(h.createdAt)}"
            box.addView(row)
        }
    }

    private fun assign() {
        if (staff.isEmpty()) {
            toast("No maintenance staff available. Add staff first.")
            return
        }
        val chosen = staff[spStaff.selectedItemPosition]
        val ok = db.assignRequest(requestId, chosen.id, user.id, etAssignNote.text.toString())
        if (ok) {
            toast("Assigned to ${chosen.name}")
            etAssignNote.setText("")
            reload()
        } else {
            toast("This request can no longer be assigned.")
            reload()
        }
    }

    private fun updateStatus() {
        val current = db.getRequest(requestId) ?: return
        val newStatus = Status.MAINTENANCE_OPTIONS[spStatus.selectedItemPosition]
        val remarks = etRemarks.text.toString().trim()

        if (newStatus == Status.COMPLETED && remarks.isEmpty()) {
            etRemarks.error = "Add completion notes before marking as completed"
            etRemarks.requestFocus()
            return
        }
        if (newStatus == current.status && remarks.isEmpty()) {
            etRemarks.error = "Change the status or add a remark"
            etRemarks.requestFocus()
            return
        }
        if (db.updateStatus(requestId, newStatus, remarks, user.id)) {
            toast("Status updated to $newStatus")
            etRemarks.setText("")
            etRemarks.error = null
            reload()
        } else {
            toast("This request can no longer be updated.")
            reload()
        }
    }
}
