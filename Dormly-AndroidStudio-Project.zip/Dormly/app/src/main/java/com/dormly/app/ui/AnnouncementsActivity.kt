package com.dormly.app.ui

import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import com.dormly.app.R
import com.dormly.app.data.Announcement
import com.dormly.app.data.Role
import com.dormly.app.util.SimpleAdapter
import com.dormly.app.util.UiUtil
import com.dormly.app.util.bind

/** Fills an item_announcement.xml row. */
fun bindAnnouncement(v: View, a: Announcement) {
    v.bind<TextView>(R.id.txtAnnTitle).text = a.title
    v.bind<TextView>(R.id.txtAnnMessage).text = a.message
    v.bind<TextView>(R.id.txtAnnMeta).text = "${a.postedByName} \u00B7 ${UiUtil.formatDate(a.createdAt)}"
}

/** Everyone can read announcements; only the admin can post. */
class AnnouncementsActivity : BaseActivity() {

    private lateinit var adapter: SimpleAdapter<Announcement>
    private lateinit var txtEmpty: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!authorized) return
        setContentView(R.layout.activity_simple_list)

        if (user.role == Role.ADMIN) {
            setupToolbar("Announcements", "+ Post") { showPostDialog() }
        } else {
            setupToolbar("Announcements")
        }

        txtEmpty = bind(R.id.txtEmpty)
        txtEmpty.text = "No announcements yet."
        adapter = SimpleAdapter(this, R.layout.item_announcement) { v, a -> bindAnnouncement(v, a) }
        bind<ListView>(R.id.listView).adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        if (!authorized) return
        load()
    }

    private fun load() {
        val list = db.getAnnouncements()
        adapter.setItems(list)
        txtEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun showPostDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_announcement, null)
        val etTitle = view.bind<EditText>(R.id.etAnnTitle)
        val etMessage = view.bind<EditText>(R.id.etAnnMessage)
        val dialog = AlertDialog.Builder(this)
            .setTitle("Post announcement")
            .setView(view)
            .setPositiveButton("Post", null)
            .setNegativeButton("Cancel", null)
            .create()
        dialog.show()
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val title = etTitle.text.toString().trim()
            val message = etMessage.text.toString().trim()
            if (title.isEmpty()) {
                etTitle.error = "Title is required"
                return@setOnClickListener
            }
            if (message.isEmpty()) {
                etMessage.error = "Message is required"
                return@setOnClickListener
            }
            db.addAnnouncement(title, message, user.id)
            dialog.dismiss()
            toast("Announcement posted")
            load()
        }
    }
}
