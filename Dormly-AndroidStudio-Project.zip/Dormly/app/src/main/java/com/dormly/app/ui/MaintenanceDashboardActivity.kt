package com.dormly.app.ui

import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.dormly.app.R
import com.dormly.app.data.Role
import com.dormly.app.data.Status
import com.dormly.app.util.Nav
import com.dormly.app.util.UiUtil
import com.dormly.app.util.bind

class MaintenanceDashboardActivity : BaseActivity() {

    override val allowedRoles = arrayOf(Role.MAINTENANCE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!authorized) return
        setContentView(R.layout.activity_maintenance_dashboard)
        setupDashboardHeader("Maintenance Personnel")
        bind<View>(R.id.btnViewTasks).setOnClickListener {
            startActivity(Nav.requests(this, null, "My Assigned Requests"))
        }
    }

    override fun onResume() {
        super.onResume()
        if (!authorized) return
        refresh()
    }

    private fun refresh() {
        val counts = db.countByStatus(assignedTo = user.id)
        val assigned = counts[Status.ASSIGNED] ?: 0
        val progress = counts[Status.IN_PROGRESS] ?: 0
        val done = counts[Status.COMPLETED] ?: 0

        val stats = bind<LinearLayout>(R.id.statsRow)
        stats.removeAllViews()
        UiUtil.addStat(stats, assigned, "To do", getColor(R.color.status_assigned))
        UiUtil.addStat(stats, progress, "In progress", getColor(R.color.status_progress))
        UiUtil.addStat(stats, done, "Completed", getColor(R.color.status_completed))

        val tasks = db.getRequests(assignedTo = user.id, excludeCompleted = true, limit = 5)
        fillRequests(bind(R.id.listTasks), tasks, true)
        bind<TextView>(R.id.txtEmptyTasks).visibility = if (tasks.isEmpty()) View.VISIBLE else View.GONE

        val tiles = listOf(
            UiUtil.Tile(R.drawable.ic_assignment, "All my tasks", "${assigned + progress + done} assigned") {
                startActivity(Nav.requests(this, null, "My Assigned Requests"))
            },
            UiUtil.Tile(R.drawable.ic_check_circle, "Completed work", "$done finished") {
                startActivity(Nav.requests(this, Status.COMPLETED, "Completed Work"))
            },
            UiUtil.Tile(R.drawable.ic_announcement, "Announcements", "Building news") {
                startActivity(Nav.announcements(this))
            }
        )
        UiUtil.buildTiles(bind(R.id.tilesBox), tiles)
    }
}
