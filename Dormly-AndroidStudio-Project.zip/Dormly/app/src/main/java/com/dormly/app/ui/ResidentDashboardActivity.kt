package com.dormly.app.ui

import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.dormly.app.R
import com.dormly.app.data.Role
import com.dormly.app.data.Status
import com.dormly.app.util.Nav
import com.dormly.app.util.UiUtil
import com.dormly.app.util.bind

class ResidentDashboardActivity : BaseActivity() {

    override val allowedRoles = arrayOf(Role.RESIDENT)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!authorized) return
        setContentView(R.layout.activity_resident_dashboard)
        setupDashboardHeader(unitLabel())

        bind<View>(R.id.btnNewRequest).setOnClickListener { startActivity(Nav.submitRequest(this)) }
        bind<View>(R.id.btnViewMine).setOnClickListener { startActivity(Nav.requests(this)) }
        bind<View>(R.id.btnViewAnn).setOnClickListener { startActivity(Nav.announcements(this)) }
    }

    private fun unitLabel(): String =
        if (user.unitNumber != null) "Unit ${user.unitNumber} \u00B7 Floor ${user.floor}" else "No unit assigned yet"

    override fun onResume() {
        super.onResume()
        if (!authorized) return
        if (!refreshUser()) return
        bind<TextView>(R.id.txtSubtitle).text = unitLabel()
        refresh()
    }

    private fun refresh() {
        val counts = db.countByStatus(residentId = user.id)
        val open = (counts[Status.PENDING] ?: 0) + (counts[Status.ASSIGNED] ?: 0) + (counts[Status.IN_PROGRESS] ?: 0)
        val done = counts[Status.COMPLETED] ?: 0

        val stats = bind<LinearLayout>(R.id.statsRow)
        stats.removeAllViews()
        UiUtil.addStat(stats, open, "Open", getColor(R.color.status_pending))
        UiUtil.addStat(stats, done, "Resolved", getColor(R.color.status_completed))
        UiUtil.addStat(stats, open + done, "Total", getColor(R.color.teal))

        val tiles = listOf(
            UiUtil.Tile(R.drawable.ic_assignment, "My requests", "Status & history") {
                startActivity(Nav.requests(this))
            },
            UiUtil.Tile(R.drawable.ic_announcement, "Announcements", "Building news") {
                startActivity(Nav.announcements(this))
            }
        )
        UiUtil.buildTiles(bind(R.id.tilesBox), tiles)

        val active = db.getRequests(residentId = user.id, excludeCompleted = true, limit = 3)
        fillRequests(bind(R.id.listActive), active, false)
        bind<TextView>(R.id.txtEmptyActive).visibility = if (active.isEmpty()) View.VISIBLE else View.GONE

        val anns = db.getAnnouncements(2)
        val box = bind<LinearLayout>(R.id.listAnnouncements)
        box.removeAllViews()
        for (a in anns) {
            val v = layoutInflater.inflate(R.layout.item_announcement, box, false)
            bindAnnouncement(v, a)
            v.setOnClickListener { startActivity(Nav.announcements(this)) }
            box.addView(v)
        }
        bind<TextView>(R.id.txtEmptyAnn).visibility = if (anns.isEmpty()) View.VISIBLE else View.GONE
    }
}
