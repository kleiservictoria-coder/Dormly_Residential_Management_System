package com.dormly.app.ui

import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import com.dormly.app.R
import com.dormly.app.data.MaintenanceRequest
import com.dormly.app.data.Role
import com.dormly.app.data.Status
import com.dormly.app.util.Nav
import com.dormly.app.util.SimpleAdapter
import com.dormly.app.util.UiUtil
import com.dormly.app.util.bind

/**
 * One list screen for all three roles:
 *  - Admin: every request in the building
 *  - Resident: only the requests they submitted
 *  - Maintenance: only requests assigned to them
 */
class RequestListActivity : BaseActivity() {

    private var filter: String? = null
    private lateinit var adapter: SimpleAdapter<MaintenanceRequest>
    private lateinit var filterRow: LinearLayout
    private lateinit var txtEmpty: TextView
    private lateinit var listView: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!authorized) return
        setContentView(R.layout.activity_request_list)

        filter = intent.getStringExtra(Nav.EXTRA_STATUS)
        val defaultTitle = when (user.role) {
            Role.ADMIN -> "All Requests"
            Role.RESIDENT -> "My Requests"
            else -> "My Assigned Requests"
        }
        val title = intent.getStringExtra(Nav.EXTRA_TITLE) ?: defaultTitle
        if (user.role == Role.RESIDENT) {
            setupToolbar(title, "+ New") { startActivity(Nav.submitRequest(this)) }
        } else {
            setupToolbar(title)
        }

        filterRow = bind(R.id.filterRow)
        txtEmpty = bind(R.id.txtEmpty)
        listView = bind(R.id.listView)

        val showResident = user.role != Role.RESIDENT
        adapter = SimpleAdapter(this, R.layout.item_request) { v, r -> UiUtil.bindRequest(v, r, showResident) }
        listView.adapter = adapter
        listView.setOnItemClickListener { _, _, position, _ ->
            startActivity(Nav.detail(this, adapter.getItem(position).id))
        }
    }

    override fun onResume() {
        super.onResume()
        if (!authorized) return
        renderFilters()
        load()
    }

    private fun filterOptions(): List<String?> =
        if (user.role == Role.MAINTENANCE) listOf(null, Status.ASSIGNED, Status.IN_PROGRESS, Status.COMPLETED)
        else listOf(null, Status.PENDING, Status.ASSIGNED, Status.IN_PROGRESS, Status.COMPLETED)

    private fun renderFilters() {
        filterRow.removeAllViews()
        val accent = getColor(if (user.role == Role.RESIDENT) R.color.teal else if (user.role == Role.ADMIN) R.color.brand else R.color.orange)
        for (option in filterOptions()) {
            val selected = option == filter
            val chip = TextView(this)
            chip.text = option ?: "All"
            chip.textSize = 13f
            chip.setPadding(UiUtil.dp(this, 16), UiUtil.dp(this, 8), UiUtil.dp(this, 16), UiUtil.dp(this, 8))
            val bg = GradientDrawable()
            bg.setCornerRadius(UiUtil.dp(this, 20).toFloat())
            if (selected) {
                bg.setColor(accent)
                chip.setTextColor(getColor(R.color.white))
            } else {
                bg.setColor(getColor(R.color.surface))
                bg.setStroke(UiUtil.dp(this, 1), getColor(R.color.border))
                chip.setTextColor(getColor(R.color.text_secondary))
            }
            chip.background = bg
            chip.isClickable = true
            chip.setOnClickListener {
                filter = option
                renderFilters()
                load()
            }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 0, UiUtil.dp(this, 8), 0)
            filterRow.addView(chip, lp)
        }
    }

    private fun load() {
        val list = when (user.role) {
            Role.ADMIN -> db.getRequests(status = filter)
            Role.RESIDENT -> db.getRequests(residentId = user.id, status = filter)
            else -> db.getRequests(assignedTo = user.id, status = filter)
        }
        adapter.setItems(list)
        txtEmpty.text = if (filter == null) "No requests yet." else "No \"$filter\" requests."
        txtEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }
}
