package com.dormly.app.util

import android.content.Context
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.dormly.app.R
import com.dormly.app.data.MaintenanceRequest
import com.dormly.app.data.Role
import com.dormly.app.data.Status
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Type-safe findViewById that compiles against any compileSdk. */
@Suppress("UNCHECKED_CAST")
fun <T : View> View.bind(id: Int): T {
    val v: View = findViewById(id)
    return v as T
}

@Suppress("UNCHECKED_CAST")
fun <T : View> android.app.Activity.bind(id: Int): T {
    val v: View = findViewById(id)
    return v as T
}

object UiUtil {

    fun dp(context: Context, value: Int): Int =
        (value * context.resources.displayMetrics.density + 0.5f).toInt()

    fun withAlpha(color: Int, alpha: Int): Int =
        Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))

    // ------------------------------------------------------------------ roles

    fun roleLabel(role: String): String = when (role) {
        Role.ADMIN -> "Building Admin"
        Role.RESIDENT -> "Resident"
        else -> "Maintenance Personnel"
    }

    fun themeFor(role: String): Int = when (role) {
        Role.ADMIN -> R.style.Theme_Dormly_Admin
        Role.RESIDENT -> R.style.Theme_Dormly_Resident
        else -> R.style.Theme_Dormly_Maintenance
    }

    fun headerBackground(context: Context, role: String): GradientDrawable {
        val (start, end) = when (role) {
            Role.ADMIN -> Pair(R.color.brand_dark, R.color.brand_light)
            Role.RESIDENT -> Pair(R.color.teal_dark, R.color.teal_light)
            else -> Pair(R.color.orange_dark, R.color.orange_light)
        }
        val r = dp(context, 30).toFloat()
        val d = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(context.getColor(start), context.getColor(end))
        )
        d.setCornerRadii(floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r))
        return d
    }

    // ----------------------------------------------------------------- status

    fun statusColor(context: Context, status: String): Int = context.getColor(
        when (status) {
            Status.PENDING -> R.color.status_pending
            Status.ASSIGNED -> R.color.status_assigned
            Status.IN_PROGRESS -> R.color.status_progress
            else -> R.color.status_completed
        }
    )

    /** Rounded "pill" with a soft tinted background. */
    fun styleChip(view: TextView, text: String, color: Int) {
        val ctx = view.context
        val bg = GradientDrawable()
        bg.setCornerRadius(dp(ctx, 20).toFloat())
        bg.setColor(withAlpha(color, 38))
        view.background = bg
        view.setTextColor(color)
        view.text = text
        view.setPadding(dp(ctx, 10), dp(ctx, 4), dp(ctx, 10), dp(ctx, 4))
    }

    fun styleStatus(view: TextView, status: String) =
        styleChip(view, status, statusColor(view.context, status))

    // ------------------------------------------------------------------- date

    fun formatDate(millis: Long): String =
        SimpleDateFormat("MMM d, yyyy \u00B7 h:mm a", Locale.getDefault()).format(Date(millis))

    fun initials(name: String): String {
        val parts = name.trim().split(" ").filter { it.isNotEmpty() }
        val text = when {
            parts.isEmpty() -> "?"
            parts.size == 1 -> parts[0].take(2)
            else -> parts[0].take(1) + parts[parts.size - 1].take(1)
        }
        val sb = StringBuilder()
        for (ch in text) sb.append(Character.toUpperCase(ch))
        return sb.toString()
    }

    // --------------------------------------------------------- list item views

    /** Fills an item_request.xml row. */
    fun bindRequest(view: View, r: MaintenanceRequest, showResident: Boolean) {
        val ctx = view.context
        val color = statusColor(ctx, r.status)

        val iconBg = GradientDrawable()
        iconBg.setShape(GradientDrawable.OVAL)
        iconBg.setColor(withAlpha(color, 38))
        view.bind<View>(R.id.viewIconBg).background = iconBg
        view.bind<ImageView>(R.id.imgIcon).setColorFilter(color, PorterDuff.Mode.SRC_IN)

        view.bind<TextView>(R.id.txtTitle).text = r.title
        val unit = if (r.unitNumber != null) "Unit ${r.unitNumber}" else "No unit"
        view.bind<TextView>(R.id.txtMeta).text =
            if (showResident) "$unit \u00B7 ${r.residentName} \u00B7 ${r.category}" else "$unit \u00B7 ${r.category}"
        view.bind<TextView>(R.id.txtDate).text = formatDate(r.createdAt)
        styleStatus(view.bind(R.id.txtStatus), r.status)
    }

    // ------------------------------------------------------- dashboard widgets

    fun addStat(row: LinearLayout, value: Int, label: String, color: Int) {
        val ctx = row.context
        val v = android.view.LayoutInflater.from(ctx).inflate(R.layout.view_stat, row, false)
        val tv = v.bind<TextView>(R.id.txtStatValue)
        tv.text = value.toString()
        tv.setTextColor(color)
        v.bind<TextView>(R.id.txtStatLabel).text = label
        val lp = v.layoutParams as LinearLayout.LayoutParams
        val gap = dp(ctx, 5)
        lp.setMargins(gap, 0, gap, 0)
        row.addView(v, lp)
    }

    class Tile(val icon: Int, val title: String, val subtitle: String, val onClick: () -> Unit)

    /** Lays [tiles] out in a grid with [columns] columns inside [box]. */
    fun buildTiles(box: LinearLayout, tiles: List<Tile>, columns: Int = 2) {
        box.removeAllViews()
        val ctx = box.context
        val inflater = android.view.LayoutInflater.from(ctx)
        val gap = dp(ctx, 5)
        var i = 0
        while (i < tiles.size) {
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            val rowLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            rowLp.setMargins(0, gap, 0, gap)
            box.addView(row, rowLp)
            for (c in 0 until columns) {
                if (i + c < tiles.size) {
                    val t = tiles[i + c]
                    val v = inflater.inflate(R.layout.view_tile, row, false)
                    v.bind<ImageView>(R.id.imgTile).setImageResource(t.icon)
                    v.bind<TextView>(R.id.txtTileTitle).text = t.title
                    v.bind<TextView>(R.id.txtTileSub).text = t.subtitle
                    v.setOnClickListener { t.onClick() }
                    val lp = v.layoutParams as LinearLayout.LayoutParams
                    lp.setMargins(gap, 0, gap, 0)
                    row.addView(v, lp)
                } else {
                    // keep the last row's tiles the same width
                    val spacer = View(ctx)
                    row.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
                }
            }
            i += columns
        }
    }
}
