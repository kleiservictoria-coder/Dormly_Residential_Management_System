#!/bin/bash
# Manual (non-Gradle) build of Dormly using aapt + kotlinc + dx + apksigner.
set -e
PROJ=/home/claude/Dormly
B=/home/claude/build/work
SDK=/usr/lib/android-sdk
ANDROID_JAR=$SDK/platforms/android-23/android.jar
KSTD=/home/claude/build/kotlin-stdlib-1.4.32.jar   # no invokedynamic -> compatible with dx
rm -rf $B && mkdir -p $B/gen $B/classes $B/dex
MAIN=$PROJ/app/src/main

# manifest with package + sdk info (Gradle injects these from build.gradle)
python3 - <<PY
s=open("$MAIN/AndroidManifest.xml").read()
s=s.replace('<manifest xmlns:android="http://schemas.android.com/apk/res/android">',
 '<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="com.dormly.app" android:versionCode="1" android:versionName="1.0">\n    <uses-sdk android:minSdkVersion="24" android:targetSdkVersion="34" />')
import re
s=re.sub(r'\s*android:roundIcon="[^"]*"','',s)  # API 25 attr; android.jar here is API 23
open("$B/AndroidManifest.xml","w").write(s)
PY

echo "== aapt: resources"
aapt package -f -m -J $B/gen -M $B/AndroidManifest.xml -S $MAIN/res -I $ANDROID_JAR \
     -F $B/res.apk --min-sdk-version 24 --target-sdk-version 34 --version-code 1 --version-name 1.0

echo "== kotlinc"
/opt/kotlinc/bin/kotlinc -no-stdlib -no-reflect -jvm-target 1.8 -api-version 1.4 -language-version 1.4 -Xsam-conversions=class -Xlambdas=class \
   -cp $ANDROID_JAR:$KSTD -d $B/classes $(find $MAIN/java -name '*.kt') $(find $B/gen -name R.java) 2>&1 | grep -v "^warning: unable to find kotlin-stdlib" || true
echo "== javac (R.java)"
javac --release 8 -cp $ANDROID_JAR:$B/classes -d $B/classes $(find $B/gen -name R.java) 2>&1 | grep -v "^warning\|^Note" || true

echo "== dx"
dalvik-exchange --dex --min-sdk-version=24 --output=$B/dex/classes.dex $B/classes $KSTD

echo "== package"
cp $B/res.apk $B/unsigned.apk
(cd $B/dex && aapt add -f $B/unsigned.apk classes.dex >/dev/null)
zipalign -f 4 $B/unsigned.apk $B/aligned.apk
[ -f /home/claude/build/debug.keystore ] || keytool -genkeypair -keystore /home/claude/build/debug.keystore \
   -storepass android -keypass android -alias androiddebugkey -keyalg RSA -keysize 2048 -validity 10000 \
   -dname "CN=Android Debug,O=Android,C=US" >/dev/null 2>&1
apksigner sign --ks /home/claude/build/debug.keystore --ks-pass pass:android --key-pass pass:android \
   --out $B/Dormly-debug.apk $B/aligned.apk
apksigner verify --verbose $B/Dormly-debug.apk | head -5
ls -la $B/Dormly-debug.apk
