package com.dormly.app.ui

import android.app.AlertDialog
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import com.dormly.app.R
import com.dormly.app.data.Role
import com.dormly.app.data.User
import com.dormly.app.util.Nav
import com.dormly.app.util.SimpleAdapter
import com.dormly.app.util.UiUtil
import com.dormly.app.util.bind

/**
 * Admin screen to manage accounts. Shows residents (with housing unit) or
 * maintenance staff depending on the role passed in the intent.
 */
class ResidentsActivity : BaseActivity() {

    override val allowedRoles = arrayOf(Role.ADMIN)

    private var listRole = Role.RESIDENT
    private lateinit var adapter: SimpleAdapter<User>
    private lateinit var txtEmpty: TextView

    private val isResidents get() = listRole == Role.RESIDENT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!authorized) return
        setContentView(R.layout.activity_simple_list)

        listRole = intent.getStringExtra(Nav.EXTRA_ROLE) ?: Role.RESIDENT
        setupToolbar(if (isResidents) "Residents" else "Maintenance Staff", "+ Add") { showUserDialog(null) }

        txtEmpty = bind(R.id.txtEmpty)
        txtEmpty.text = if (isResidents) "No residents yet. Tap + Add to create one." else "No maintenance staff yet."

        adapter = SimpleAdapter(this, R.layout.item_user) { v, u ->
            v.bind<TextView>(R.id.txtInitials).text = UiUtil.initials(u.name)
            v.bind<TextView>(R.id.txtName).text = u.name
            v.bind<TextView>(R.id.txtEmail).text = u.email
            val chip = v.bind<TextView>(R.id.txtUnit)
            if (isResidents) {
                chip.visibility = View.VISIBLE
                if (u.unitNumber != null) UiUtil.styleChip(chip, "Unit ${u.unitNumber}", getColor(R.color.status_completed))
                else UiUtil.styleChip(chip, "No unit", getColor(R.color.status_pending))
            } else {
                chip.visibility = View.GONE
            }
        }
        val list = bind<ListView>(R.id.listView)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, position, _ -> showUserDialog(adapter.getItem(position)) }
    }

    override fun onResume() {
        super.onResume()
        if (!authorized) return
        load()
    }

    private fun load() {
        val users = db.getUsersByRole(listRole)
        adapter.setItems(users)
        txtEmpty.visibility = if (users.isEmpty()) View.VISIBLE else View.GONE
    }

    /** Add (existing == null) or edit a user. */
    private fun showUserDialog(existing: User?) {
        val view = layoutInflater.inflate(R.layout.dialog_user, null)
        val etName = view.bind<EditText>(R.id.etName)
        val etEmail = view.bind<EditText>(R.id.etEmail)
        val etPassword = view.bind<EditText>(R.id.etPassword)
        val etPhone = view.bind<EditText>(R.id.etPhone)
        val spUnit = view.bind<Spinner>(R.id.spUnit)
        val layoutUnit = view.bind<View>(R.id.layoutUnit)

        val units = db.getUnits()
        val unitLabels = listOf("No unit assigned") + units.map { "Unit ${it.number} \u00B7 Floor ${it.floor}" }
        spUnit.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, unitLabels).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        layoutUnit.visibility = if (isResidents) View.VISIBLE else View.GONE

        if (existing != null) {
            etName.setText(existing.name)
            etEmail.setText(existing.email)
            etEmail.isEnabled = false
            etEmail.alpha = 0.6f
            etPassword.visibility = View.GONE
            etPhone.setText(existing.phone)
            val idx = units.indexOfFirst { it.id == existing.unitId }
            spUnit.setSelection(if (idx >= 0) idx + 1 else 0)
        }

        val builder = AlertDialog.Builder(this)
            .setTitle(
                when {
                    existing != null -> "Edit ${if (isResidents) "resident" else "staff member"}"
                    isResidents -> "Add resident"
                    else -> "Add maintenance staff"
                }
            )
            .setView(view)
            .setPositiveButton(if (existing == null) "Add" else "Save", null)
            .setNegativeButton("Cancel", null)
        if (existing != null) builder.setNeutralButton("Remove", null)
        val dialog = builder.create()
        dialog.show()

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val name = etName.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString()
            val phone = etPhone.text.toString().trim()
            val unitId: Long? = if (isResidents && spUnit.selectedItemPosition > 0)
                units[spUnit.selectedItemPosition - 1].id else null

            if (name.isEmpty()) { etName.error = "Name is required"; return@setOnClickListener }
            if (existing == null) {
                if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    etEmail.error = "Enter a valid email address"; return@setOnClickListener
                }
                if (password.length < 6) {
                    etPassword.error = "Password must be at least 6 characters"; return@setOnClickListener
                }
                val id = db.addUser(name, email, password, listRole, phone, unitId)
                if (id < 0) { etEmail.error = "This email is already registered"; return@setOnClickListener }
                toast("Account created for $name")
            } else {
                db.updateUser(existing.id, name, phone, unitId)
                toast("Changes saved")
            }
            dialog.dismiss()
            load()
        }

        if (existing != null) {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                val warning = if (isResidents)
                    "${existing.name} and all of their maintenance requests will be deleted."
                else
                    "${existing.name} will be removed. Their open requests go back to Pending."
                AlertDialog.Builder(this)
                    .setTitle("Remove ${existing.name}?")
                    .setMessage(warning)
                    .setPositiveButton("Remove") { _, _ ->
                        db.deleteUser(existing.id)
                        dialog.dismiss()
                        toast("Account removed")
                        load()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        }
    }
}
