package com.dormly.app.data

object Role {
    const val ADMIN = "ADMIN"
    const val RESIDENT = "RESIDENT"
    const val MAINTENANCE = "MAINTENANCE"
}

object Status {
    const val PENDING = "Pending"
    const val ASSIGNED = "Assigned"
    const val IN_PROGRESS = "In Progress"
    const val COMPLETED = "Completed"

    /** Statuses a maintenance staff member may set. */
    val MAINTENANCE_OPTIONS = listOf(ASSIGNED, IN_PROGRESS, COMPLETED)
}

object Options {
    val CATEGORIES = listOf(
        "Plumbing", "Electrical", "Air Conditioning", "Furniture",
        "Appliances", "Cleaning", "Security", "Other"
    )
    val PRIORITIES = listOf("Low", "Medium", "High")
    val UNIT_TYPES = listOf("Studio", "Single Room", "Shared Room", "1-Bedroom", "2-Bedroom")
}

data class User(
    val id: Long,
    val name: String,
    val email: String,
    val role: String,
    val phone: String,
    val unitId: Long?,
    val unitNumber: String?,
    val floor: String?
)

data class HousingUnit(
    val id: Long,
    val number: String,
    val floor: String,
    val type: String,
    val residentCount: Int,
    val residentNames: String
)

data class MaintenanceRequest(
    val id: Long,
    val residentId: Long,
    val residentName: String,
    val unitNumber: String?,
    val title: String,
    val description: String,
    val category: String,
    val priority: String,
    val status: String,
    val assignedToId: Long?,
    val assignedToName: String?,
    val createdAt: Long,
    val updatedAt: Long
)

data class StatusUpdate(
    val id: Long,
    val requestId: Long,
    val status: String,
    val remarks: String,
    val updatedByName: String,
    val createdAt: Long
)

data class Announcement(
    val id: Long,
    val title: String,
    val message: String,
    val postedByName: String,
    val createdAt: Long
)
