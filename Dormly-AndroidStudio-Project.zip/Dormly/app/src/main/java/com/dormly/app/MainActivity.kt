package com.dormly.app

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.dormly.app.data.DormlyDb
import com.dormly.app.util.Nav
import com.dormly.app.util.Session

/**
 * Launcher activity (splash). Creates/opens the local database, then routes to
 * the signed-in user's dashboard, or to the Login screen when nobody is signed in.
 */
class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        handler.postDelayed({ route() }, 900)
    }

    private fun route() {
        if (isFinishing) return
        DormlyDb.get(this).writableDatabase // creates + seeds the database on first launch
        val user = Session.currentUser(this)
        startActivity(if (user == null) Nav.login(this) else Nav.dashboard(this, user))
        finish()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
