package com.dormly.app.ui

import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.dormly.app.R
import com.dormly.app.data.Role
import com.dormly.app.data.Status
import com.dormly.app.util.Nav
import com.dormly.app.util.UiUtil
import com.dormly.app.util.bind

class AdminDashboardActivity : BaseActivity() {

    override val allowedRoles = arrayOf(Role.ADMIN)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!authorized) return
        setContentView(R.layout.activity_admin_dashboard)
        setupDashboardHeader("Building Admin")
        bind<View>(R.id.btnViewAll).setOnClickListener {
            startActivity(Nav.requests(this, Status.PENDING, "Pending Requests"))
        }
    }

    override fun onResume() {
        super.onResume()
        if (!authorized) return
        refresh()
    }

    private fun refresh() {
        val counts = db.countByStatus()
        val pending = counts[Status.PENDING] ?: 0
        val active = (counts[Status.ASSIGNED] ?: 0) + (counts[Status.IN_PROGRESS] ?: 0)
        val done = counts[Status.COMPLETED] ?: 0
        val total = pending + active + done

        val stats = bind<LinearLayout>(R.id.statsRow)
        stats.removeAllViews()
        UiUtil.addStat(stats, pending, "Pending", getColor(R.color.status_pending))
        UiUtil.addStat(stats, active, "In progress", getColor(R.color.status_progress))
        UiUtil.addStat(stats, done, "Completed", getColor(R.color.status_completed))

        val tiles = listOf(
            UiUtil.Tile(R.drawable.ic_assignment, "Requests", "$total total") {
                startActivity(Nav.requests(this))
            },
            UiUtil.Tile(R.drawable.ic_history, "History", "$done completed") {
                startActivity(Nav.requests(this, Status.COMPLETED, "Request History"))
            },
            UiUtil.Tile(R.drawable.ic_people, "Residents", "${db.countUsers(Role.RESIDENT)} registered") {
                startActivity(Nav.users(this, Role.RESIDENT))
            },
            UiUtil.Tile(R.drawable.ic_engineering, "Maintenance staff", "${db.countUsers(Role.MAINTENANCE)} members") {
                startActivity(Nav.users(this, Role.MAINTENANCE))
            },
            UiUtil.Tile(R.drawable.ic_business, "Housing units", "${db.countUnits()} units") {
                startActivity(Nav.units(this))
            },
            UiUtil.Tile(R.drawable.ic_announcement, "Announcements", "Post updates") {
                startActivity(Nav.announcements(this))
            }
        )
        UiUtil.buildTiles(bind(R.id.tilesBox), tiles)

        val pendingList = db.getRequests(status = Status.PENDING, limit = 5)
        fillRequests(bind(R.id.listPending), pendingList, true)
        bind<TextView>(R.id.txtEmptyPending).visibility = if (pendingList.isEmpty()) View.VISIBLE else View.GONE
    }
}
