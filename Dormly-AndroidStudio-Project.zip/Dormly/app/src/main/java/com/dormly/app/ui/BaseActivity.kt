package com.dormly.app.ui

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.dormly.app.R
import com.dormly.app.data.DormlyDb
import com.dormly.app.data.MaintenanceRequest
import com.dormly.app.data.User
import com.dormly.app.util.Nav
import com.dormly.app.util.Session
import com.dormly.app.util.UiUtil
import com.dormly.app.util.bind

/**
 * Base class for every screen that needs a signed-in user.
 * - Sends the user back to Login if there is no session or the role is not allowed.
 * - Applies the role colour theme (indigo = admin, teal = resident, orange = maintenance).
 */
open class BaseActivity : Activity() {

    protected lateinit var db: DormlyDb
    protected lateinit var user: User

    /** True once the session check passed; subclasses must stop in onCreate/onResume when false. */
    protected var authorized = false

    /** Roles allowed on this screen (empty = any signed-in user). */
    protected open val allowedRoles: Array<String> = emptyArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        db = DormlyDb.get(this)
        val current = Session.currentUser(this)
        if (current == null || (allowedRoles.isNotEmpty() && current.role !in allowedRoles)) {
            super.onCreate(savedInstanceState)
            Session.logout(this)
            startActivity(Nav.login(this))
            finish()
            return
        }
        user = current
        setTheme(UiUtil.themeFor(current.role))
        super.onCreate(savedInstanceState)
        authorized = true
    }

    /** Reloads the signed-in user (e.g. after the admin changed their unit). */
    protected fun refreshUser(): Boolean {
        val fresh = db.getUser(user.id)
        if (fresh == null) {
            Session.logout(this)
            startActivity(Nav.login(this))
            finish()
            return false
        }
        user = fresh
        return true
    }

    protected fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    /** Wires the shared toolbar (title + back arrow + optional action button). */
    protected fun setupToolbar(title: String, actionText: String? = null, onAction: (() -> Unit)? = null) {
        bind<TextView>(R.id.toolbarTitle).text = title
        bind<View>(R.id.btnBack).setOnClickListener { finish() }
        val action = bind<TextView>(R.id.btnAction)
        if (actionText != null && onAction != null) {
            action.text = actionText
            action.visibility = View.VISIBLE
            action.setOnClickListener { onAction() }
        } else {
            action.visibility = View.GONE
        }
    }

    /** Fills the coloured header used by the three dashboards. */
    protected fun setupDashboardHeader(subtitle: String) {
        bind<View>(R.id.headerBox).background = UiUtil.headerBackground(this, user.role)
        bind<TextView>(R.id.txtName).text = user.name
        bind<TextView>(R.id.txtSubtitle).text = subtitle
        bind<View>(R.id.btnLogout).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Log out")
                .setMessage("Do you want to log out of Dormly?")
                .setPositiveButton("Log out") { _, _ ->
                    Session.logout(this)
                    startActivity(Nav.login(this))
                    finish()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    /** Inflates request cards into a vertical container (used on dashboards). */
    protected fun fillRequests(container: LinearLayout, items: List<MaintenanceRequest>, showResident: Boolean) {
        container.removeAllViews()
        for (r in items) {
            val v = layoutInflater.inflate(R.layout.item_request, container, false)
            UiUtil.bindRequest(v, r, showResident)
            v.setOnClickListener { startActivity(Nav.detail(this, r.id)) }
            container.addView(v)
        }
    }
}
