package com.dormly.app.ui

import android.app.Activity
import android.os.Bundle
import android.util.Patterns
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.dormly.app.R
import com.dormly.app.data.DormlyDb
import com.dormly.app.util.Nav
import com.dormly.app.util.Session
import com.dormly.app.util.bind

class LoginActivity : Activity() {

    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var txtError: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        etEmail = bind(R.id.etEmail)
        etPassword = bind(R.id.etPassword)
        txtError = bind(R.id.txtError)

        bind<Button>(R.id.btnLogin).setOnClickListener { attemptLogin() }
        etPassword.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                attemptLogin()
                true
            } else false
        }

        bind<Button>(R.id.btnDemoAdmin).setOnClickListener { fill("admin@dormly.com") }
        bind<Button>(R.id.btnDemoResident).setOnClickListener { fill("resident@dormly.com") }
        bind<Button>(R.id.btnDemoMaint).setOnClickListener { fill("maintenance@dormly.com") }
    }

    private fun fill(email: String) {
        etEmail.setText(email)
        etPassword.setText("dormly123")
        etEmail.error = null
        etPassword.error = null
        txtError.visibility = android.view.View.GONE
    }

    private fun attemptLogin() {
        txtError.visibility = android.view.View.GONE
        val email = etEmail.text.toString().trim()
        val password = etPassword.text.toString()

        if (email.isEmpty()) {
            etEmail.error = "Email is required"
            etEmail.requestFocus()
            return
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.error = "Enter a valid email address"
            etEmail.requestFocus()
            return
        }
        if (password.isEmpty()) {
            etPassword.error = "Password is required"
            etPassword.requestFocus()
            return
        }

        val user = DormlyDb.get(this).login(email, password)
        if (user == null) {
            txtError.text = "Incorrect email or password. Please try again."
            txtError.visibility = android.view.View.VISIBLE
            return
        }
        Session.login(this, user)
        startActivity(Nav.dashboard(this, user))
        finish()
    }
}
