package com.dormly.app.util

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter

/** Minimal list adapter: inflates [layout] for each item and lets [binder] fill it. */
class SimpleAdapter<T>(
    private val context: Context,
    private val layout: Int,
    private val binder: (View, T) -> Unit
) : BaseAdapter() {

    private var items: List<T> = emptyList()

    fun setItems(newItems: List<T>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun getCount(): Int = items.size
    override fun getItem(position: Int): T = items[position]
    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = convertView ?: LayoutInflater.from(context).inflate(layout, parent, false)
        binder(view, items[position])
        return view
    }
}
