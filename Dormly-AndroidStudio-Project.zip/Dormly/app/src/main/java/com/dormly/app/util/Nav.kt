package com.dormly.app.util

import android.content.Context
import android.content.Intent
import com.dormly.app.data.Role
import com.dormly.app.data.User
import com.dormly.app.ui.AdminDashboardActivity
import com.dormly.app.ui.AnnouncementsActivity
import com.dormly.app.ui.LoginActivity
import com.dormly.app.ui.MaintenanceDashboardActivity
import com.dormly.app.ui.RequestDetailActivity
import com.dormly.app.ui.RequestListActivity
import com.dormly.app.ui.ResidentDashboardActivity
import com.dormly.app.ui.ResidentsActivity
import com.dormly.app.ui.SubmitRequestActivity
import com.dormly.app.ui.UnitsActivity

/** Central place that builds the intents used to move between screens. */
object Nav {
    const val EXTRA_STATUS = "status"
    const val EXTRA_REQUEST_ID = "request_id"
    const val EXTRA_ROLE = "role"
    const val EXTRA_TITLE = "title"

    private const val CLEAR = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK

    fun dashboard(context: Context, user: User): Intent {
        val cls = when (user.role) {
            Role.ADMIN -> AdminDashboardActivity::class.java
            Role.RESIDENT -> ResidentDashboardActivity::class.java
            else -> MaintenanceDashboardActivity::class.java
        }
        return Intent(context, cls).addFlags(CLEAR)
    }

    fun login(context: Context): Intent = Intent(context, LoginActivity::class.java).addFlags(CLEAR)

    fun requests(context: Context, status: String? = null, title: String? = null): Intent {
        val i = Intent(context, RequestListActivity::class.java)
        if (status != null) i.putExtra(EXTRA_STATUS, status)
        if (title != null) i.putExtra(EXTRA_TITLE, title)
        return i
    }

    fun detail(context: Context, requestId: Long): Intent =
        Intent(context, RequestDetailActivity::class.java).putExtra(EXTRA_REQUEST_ID, requestId)

    fun submitRequest(context: Context): Intent = Intent(context, SubmitRequestActivity::class.java)

    fun announcements(context: Context): Intent = Intent(context, AnnouncementsActivity::class.java)

    fun users(context: Context, role: String): Intent =
        Intent(context, ResidentsActivity::class.java).putExtra(EXTRA_ROLE, role)

    fun units(context: Context): Intent = Intent(context, UnitsActivity::class.java)
}
