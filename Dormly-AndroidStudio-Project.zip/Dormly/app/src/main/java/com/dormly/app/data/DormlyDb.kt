package com.dormly.app.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteConstraintException
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.security.MessageDigest

/**
 * Single local SQLite database shared by all roles (admin, resident, maintenance).
 * Tables: users, units, requests, assignments, status_updates, announcements.
 */
class DormlyDb private constructor(context: Context) :
    SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    companion object {
        private const val DB_NAME = "dormly.db"
        private const val DB_VERSION = 1
        private const val DAY = 24L * 60 * 60 * 1000

        @Volatile
        private var instance: DormlyDb? = null

        fun get(context: Context): DormlyDb =
            instance ?: synchronized(this) {
                instance ?: DormlyDb(context.applicationContext).also { instance = it }
            }

        fun hash(password: String): String {
            val bytes = MessageDigest.getInstance("SHA-256").digest(("dormly::$password").toByteArray())
            return bytes.joinToString("") { "%02x".format(it) }
        }

        private const val USER_SELECT =
            "SELECT u.id, u.name, u.email, u.role, u.phone, u.unit_id, un.unit_number, un.floor " +
                "FROM users u LEFT JOIN units un ON un.id = u.unit_id "

        private const val REQUEST_SELECT =
            "SELECT r.id, r.resident_id, ru.name, un.unit_number, r.title, r.description, r.category, " +
                "r.priority, r.status, r.assigned_to, mu.name, r.created_at, r.updated_at " +
                "FROM requests r " +
                "JOIN users ru ON ru.id = r.resident_id " +
                "LEFT JOIN units un ON un.id = r.unit_id " +
                "LEFT JOIN users mu ON mu.id = r.assigned_to "
    }

    // ------------------------------------------------------------------ schema

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE units (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "unit_number TEXT NOT NULL UNIQUE COLLATE NOCASE, " +
                "floor TEXT NOT NULL, " +
                "unit_type TEXT NOT NULL)"
        )
        db.execSQL(
            "CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT NOT NULL, " +
                "email TEXT NOT NULL UNIQUE COLLATE NOCASE, " +
                "password_hash TEXT NOT NULL, " +
                "role TEXT NOT NULL, " +
                "phone TEXT NOT NULL DEFAULT '', " +
                "unit_id INTEGER REFERENCES units(id) ON DELETE SET NULL)"
        )
        db.execSQL(
            "CREATE TABLE requests (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "resident_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, " +
                "unit_id INTEGER REFERENCES units(id) ON DELETE SET NULL, " +
                "title TEXT NOT NULL, " +
                "description TEXT NOT NULL, " +
                "category TEXT NOT NULL, " +
                "priority TEXT NOT NULL, " +
                "status TEXT NOT NULL, " +
                "assigned_to INTEGER REFERENCES users(id) ON DELETE SET NULL, " +
                "created_at INTEGER NOT NULL, " +
                "updated_at INTEGER NOT NULL)"
        )
        db.execSQL(
            "CREATE TABLE assignments (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "request_id INTEGER NOT NULL REFERENCES requests(id) ON DELETE CASCADE, " +
                "maintenance_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, " +
                "assigned_by INTEGER REFERENCES users(id) ON DELETE SET NULL, " +
                "assigned_at INTEGER NOT NULL)"
        )
        db.execSQL(
            "CREATE TABLE status_updates (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "request_id INTEGER NOT NULL REFERENCES requests(id) ON DELETE CASCADE, " +
                "status TEXT NOT NULL, " +
                "remarks TEXT NOT NULL DEFAULT '', " +
                "updated_by INTEGER REFERENCES users(id) ON DELETE SET NULL, " +
                "created_at INTEGER NOT NULL)"
        )
        db.execSQL(
            "CREATE TABLE announcements (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "title TEXT NOT NULL, " +
                "message TEXT NOT NULL, " +
                "posted_by INTEGER REFERENCES users(id) ON DELETE SET NULL, " +
                "created_at INTEGER NOT NULL)"
        )
        seed(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Version 1 only - nothing to migrate yet.
    }

    // -------------------------------------------------------------- sample data

    private fun seed(db: SQLiteDatabase) {
        val now = System.currentTimeMillis()

        val u101 = insertUnit(db, "101", "1", "Studio")
        val u102 = insertUnit(db, "102", "1", "Single Room")
        insertUnit(db, "103", "1", "Shared Room")
        val u201 = insertUnit(db, "201", "2", "1-Bedroom")
        insertUnit(db, "202", "2", "1-Bedroom")
        insertUnit(db, "301", "3", "2-Bedroom")

        val admin = insertUser(db, "Grace Mendoza", "admin@dormly.com", "dormly123", Role.ADMIN, "0917 555 0100", null)
        val juan = insertUser(db, "Juan Dela Cruz", "resident@dormly.com", "dormly123", Role.RESIDENT, "0917 555 0101", u101)
        val maria = insertUser(db, "Maria Santos", "maria@dormly.com", "dormly123", Role.RESIDENT, "0917 555 0102", u102)
        insertUser(db, "Paolo Lim", "paolo@dormly.com", "dormly123", Role.RESIDENT, "0917 555 0103", u201)
        val carlo = insertUser(db, "Carlo Reyes", "maintenance@dormly.com", "dormly123", Role.MAINTENANCE, "0917 555 0200", null)
        insertUser(db, "Ana Villanueva", "ana@dormly.com", "dormly123", Role.MAINTENANCE, "0917 555 0201", null)

        // Request 1: pending (resident just submitted it)
        val r1 = insertRequest(
            db, juan, u101, "Leaking kitchen faucet",
            "The faucet keeps dripping even when fully closed. Water pools in the sink overnight.",
            "Plumbing", "Medium", Status.PENDING, null, now - 2 * 60 * 60 * 1000
        )
        insertStatus(db, r1, Status.PENDING, "Request submitted", juan, now - 2 * 60 * 60 * 1000)

        // Request 2: in progress, assigned to Carlo
        val t2 = now - 2 * DAY
        val r2 = insertRequest(
            db, maria, u102, "Hallway light not working",
            "The light outside my room flickers and turns off by itself.",
            "Electrical", "High", Status.IN_PROGRESS, carlo, t2
        )
        insertStatus(db, r2, Status.PENDING, "Request submitted", maria, t2)
        insertAssignment(db, r2, carlo, admin, t2 + 3 * 60 * 60 * 1000)
        insertStatus(db, r2, Status.ASSIGNED, "Assigned to Carlo Reyes", admin, t2 + 3 * 60 * 60 * 1000)
        insertStatus(db, r2, Status.IN_PROGRESS, "Checking the wiring and replacing the bulb.", carlo, t2 + DAY)
        db.execSQL("UPDATE requests SET updated_at = ? WHERE id = ?", arrayOf<Any>(t2 + DAY, r2))

        // Request 3: completed (history)
        val t3 = now - 6 * DAY
        val r3 = insertRequest(
            db, juan, u101, "Air conditioner is noisy",
            "The aircon makes a loud rattling noise when it is on.",
            "Air Conditioning", "Low", Status.COMPLETED, carlo, t3
        )
        insertStatus(db, r3, Status.PENDING, "Request submitted", juan, t3)
        insertAssignment(db, r3, carlo, admin, t3 + 2 * 60 * 60 * 1000)
        insertStatus(db, r3, Status.ASSIGNED, "Assigned to Carlo Reyes", admin, t3 + 2 * 60 * 60 * 1000)
        insertStatus(db, r3, Status.IN_PROGRESS, "On site, inspecting the unit.", carlo, t3 + DAY)
        insertStatus(db, r3, Status.COMPLETED, "Cleaned the filter and tightened the fan housing. Works quietly now.", carlo, t3 + DAY + 4 * 60 * 60 * 1000)
        db.execSQL("UPDATE requests SET updated_at = ? WHERE id = ?", arrayOf<Any>(t3 + DAY + 4 * 60 * 60 * 1000, r3))

        insertAnnouncement(
            db, "Water interruption on Saturday",
            "Water supply will be off from 9:00 AM to 12:00 NN for pipe maintenance. Please store water ahead of time.",
            admin, now - 1 * DAY
        )
        insertAnnouncement(
            db, "Welcome to Dormly!",
            "Report any issues in your unit through the app. Our maintenance team will take it from there.",
            admin, now - 5 * DAY
        )
    }

    private fun insertUnit(db: SQLiteDatabase, number: String, floor: String, type: String): Long {
        val cv = ContentValues()
        cv.put("unit_number", number)
        cv.put("floor", floor)
        cv.put("unit_type", type)
        return db.insertOrThrow("units", null, cv)
    }

    private fun insertUser(
        db: SQLiteDatabase, name: String, email: String, password: String,
        role: String, phone: String, unitId: Long?
    ): Long {
        val cv = ContentValues()
        cv.put("name", name)
        cv.put("email", email)
        cv.put("password_hash", hash(password))
        cv.put("role", role)
        cv.put("phone", phone)
        if (unitId != null) cv.put("unit_id", unitId) else cv.putNull("unit_id")
        return db.insertOrThrow("users", null, cv)
    }

    private fun insertRequest(
        db: SQLiteDatabase, residentId: Long, unitId: Long?, title: String, description: String,
        category: String, priority: String, status: String, assignedTo: Long?, createdAt: Long
    ): Long {
        val cv = ContentValues()
        cv.put("resident_id", residentId)
        if (unitId != null) cv.put("unit_id", unitId) else cv.putNull("unit_id")
        cv.put("title", title)
        cv.put("description", description)
        cv.put("category", category)
        cv.put("priority", priority)
        cv.put("status", status)
        if (assignedTo != null) cv.put("assigned_to", assignedTo) else cv.putNull("assigned_to")
        cv.put("created_at", createdAt)
        cv.put("updated_at", createdAt)
        return db.insertOrThrow("requests", null, cv)
    }

    private fun insertStatus(db: SQLiteDatabase, requestId: Long, status: String, remarks: String, by: Long?, at: Long) {
        val cv = ContentValues()
        cv.put("request_id", requestId)
        cv.put("status", status)
        cv.put("remarks", remarks)
        if (by != null) cv.put("updated_by", by) else cv.putNull("updated_by")
        cv.put("created_at", at)
        db.insertOrThrow("status_updates", null, cv)
    }

    private fun insertAssignment(db: SQLiteDatabase, requestId: Long, maintenanceId: Long, by: Long, at: Long) {
        val cv = ContentValues()
        cv.put("request_id", requestId)
        cv.put("maintenance_id", maintenanceId)
        cv.put("assigned_by", by)
        cv.put("assigned_at", at)
        db.insertOrThrow("assignments", null, cv)
    }

    private fun insertAnnouncement(db: SQLiteDatabase, title: String, message: String, by: Long, at: Long) {
        val cv = ContentValues()
        cv.put("title", title)
        cv.put("message", message)
        cv.put("posted_by", by)
        cv.put("created_at", at)
        db.insertOrThrow("announcements", null, cv)
    }

    // -------------------------------------------------------------------- users

    private fun readUser(c: Cursor) = User(
        id = c.getLong(0),
        name = c.getString(1),
        email = c.getString(2),
        role = c.getString(3),
        phone = c.getString(4) ?: "",
        unitId = if (c.isNull(5)) null else c.getLong(5),
        unitNumber = if (c.isNull(6)) null else c.getString(6),
        floor = if (c.isNull(7)) null else c.getString(7)
    )

    /** Returns the matching user, or null when the email/password is wrong. */
    fun login(email: String, password: String): User? {
        readableDatabase.rawQuery(
            USER_SELECT + "WHERE u.email = ? COLLATE NOCASE AND u.password_hash = ?",
            arrayOf(email.trim(), hash(password))
        ).use { c -> return if (c.moveToFirst()) readUser(c) else null }
    }

    fun getUser(id: Long): User? {
        readableDatabase.rawQuery(USER_SELECT + "WHERE u.id = ?", arrayOf(id.toString())).use { c ->
            return if (c.moveToFirst()) readUser(c) else null
        }
    }

    fun getUsersByRole(role: String): List<User> {
        val list = ArrayList<User>()
        readableDatabase.rawQuery(USER_SELECT + "WHERE u.role = ? ORDER BY u.name COLLATE NOCASE", arrayOf(role)).use { c ->
            while (c.moveToNext()) list.add(readUser(c))
        }
        return list
    }

    fun countUsers(role: String): Int = scalar("SELECT COUNT(*) FROM users WHERE role = ?", arrayOf(role))

    /** @return new user id, or -1 when the email is already registered. */
    fun addUser(name: String, email: String, password: String, role: String, phone: String, unitId: Long?): Long {
        return try {
            insertUser(writableDatabase, name, email.trim(), password, role, phone, unitId)
        } catch (e: SQLiteConstraintException) {
            -1L
        }
    }

    fun updateUser(id: Long, name: String, phone: String, unitId: Long?) {
        val cv = ContentValues()
        cv.put("name", name)
        cv.put("phone", phone)
        if (unitId != null) cv.put("unit_id", unitId) else cv.putNull("unit_id")
        writableDatabase.update("users", cv, "id = ?", arrayOf(id.toString()))
    }

    fun deleteUser(id: Long) {
        val db = writableDatabase
        val now = System.currentTimeMillis()
        db.beginTransaction()
        try {
            // Work that was assigned to a removed staff member goes back to the admin's queue.
            val open = ArrayList<Long>()
            db.rawQuery(
                "SELECT id FROM requests WHERE assigned_to = ? AND status != ?",
                arrayOf(id.toString(), Status.COMPLETED)
            ).use { c -> while (c.moveToNext()) open.add(c.getLong(0)) }
            for (rid in open) {
                db.execSQL(
                    "UPDATE requests SET status = ?, assigned_to = NULL, updated_at = ? WHERE id = ?",
                    arrayOf<Any>(Status.PENDING, now, rid)
                )
                insertStatus(db, rid, Status.PENDING, "Maintenance staff removed - needs reassignment", null, now)
            }
            db.delete("users", "id = ?", arrayOf(id.toString()))
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    // -------------------------------------------------------------------- units

    fun getUnits(): List<HousingUnit> {
        val list = ArrayList<HousingUnit>()
        readableDatabase.rawQuery(
            "SELECT un.id, un.unit_number, un.floor, un.unit_type, " +
                "(SELECT COUNT(*) FROM users u WHERE u.unit_id = un.id), " +
                "(SELECT group_concat(u.name, ', ') FROM users u WHERE u.unit_id = un.id) " +
                "FROM units un ORDER BY un.unit_number COLLATE NOCASE", null
        ).use { c ->
            while (c.moveToNext()) {
                list.add(
                    HousingUnit(
                        c.getLong(0), c.getString(1), c.getString(2), c.getString(3),
                        c.getInt(4), if (c.isNull(5)) "" else c.getString(5)
                    )
                )
            }
        }
        return list
    }

    fun countUnits(): Int = scalar("SELECT COUNT(*) FROM units", null)

    /** @return new unit id, or -1 when the unit number already exists. */
    fun addUnit(number: String, floor: String, type: String): Long {
        return try {
            insertUnit(writableDatabase, number.trim(), floor.trim(), type)
        } catch (e: SQLiteConstraintException) {
            -1L
        }
    }

    fun deleteUnit(id: Long) {
        writableDatabase.delete("units", "id = ?", arrayOf(id.toString()))
    }

    // ----------------------------------------------------------------- requests

    private fun readRequest(c: Cursor) = MaintenanceRequest(
        id = c.getLong(0),
        residentId = c.getLong(1),
        residentName = c.getString(2),
        unitNumber = if (c.isNull(3)) null else c.getString(3),
        title = c.getString(4),
        description = c.getString(5),
        category = c.getString(6),
        priority = c.getString(7),
        status = c.getString(8),
        assignedToId = if (c.isNull(9)) null else c.getLong(9),
        assignedToName = if (c.isNull(10)) null else c.getString(10),
        createdAt = c.getLong(11),
        updatedAt = c.getLong(12)
    )

    /** Resident submits a new request (status starts as Pending). */
    fun createRequest(resident: User, title: String, description: String, category: String, priority: String): Long {
        val db = writableDatabase
        val now = System.currentTimeMillis()
        db.beginTransaction()
        try {
            val id = insertRequest(
                db, resident.id, resident.unitId, title, description,
                category, priority, Status.PENDING, null, now
            )
            insertStatus(db, id, Status.PENDING, "Request submitted", resident.id, now)
            db.setTransactionSuccessful()
            return id
        } finally {
            db.endTransaction()
        }
    }

    /**
     * Query requests.
     * @param residentId only requests submitted by this resident
     * @param assignedTo only requests assigned to this maintenance user
     * @param status exact status filter
     * @param excludeCompleted hide completed requests
     * @param limit 0 = no limit
     */
    fun getRequests(
        residentId: Long? = null,
        assignedTo: Long? = null,
        status: String? = null,
        excludeCompleted: Boolean = false,
        limit: Int = 0
    ): List<MaintenanceRequest> {
        val where = ArrayList<String>()
        val args = ArrayList<String>()
        if (residentId != null) { where.add("r.resident_id = ?"); args.add(residentId.toString()) }
        if (assignedTo != null) { where.add("r.assigned_to = ?"); args.add(assignedTo.toString()) }
        if (status != null) { where.add("r.status = ?"); args.add(status) }
        if (excludeCompleted) { where.add("r.status != ?"); args.add(Status.COMPLETED) }
        var sql = REQUEST_SELECT
        if (where.isNotEmpty()) sql += "WHERE " + where.joinToString(" AND ") + " "
        sql += "ORDER BY r.updated_at DESC, r.id DESC"
        if (limit > 0) sql += " LIMIT $limit"
        val list = ArrayList<MaintenanceRequest>()
        readableDatabase.rawQuery(sql, args.toTypedArray()).use { c ->
            while (c.moveToNext()) list.add(readRequest(c))
        }
        return list
    }

    fun getRequest(id: Long): MaintenanceRequest? {
        readableDatabase.rawQuery(REQUEST_SELECT + "WHERE r.id = ?", arrayOf(id.toString())).use { c ->
            return if (c.moveToFirst()) readRequest(c) else null
        }
    }

    /** Number of requests per status for the given scope. */
    fun countByStatus(residentId: Long? = null, assignedTo: Long? = null): Map<String, Int> {
        val where = ArrayList<String>()
        val args = ArrayList<String>()
        if (residentId != null) { where.add("resident_id = ?"); args.add(residentId.toString()) }
        if (assignedTo != null) { where.add("assigned_to = ?"); args.add(assignedTo.toString()) }
        var sql = "SELECT status, COUNT(*) FROM requests "
        if (where.isNotEmpty()) sql += "WHERE " + where.joinToString(" AND ") + " "
        sql += "GROUP BY status"
        val map = HashMap<String, Int>()
        readableDatabase.rawQuery(sql, args.toTypedArray()).use { c ->
            while (c.moveToNext()) map[c.getString(0)] = c.getInt(1)
        }
        return map
    }

    /**
     * Admin assigns (or reassigns) a request to a maintenance staff member.
     * @return false when the request no longer exists or is already completed.
     */
    fun assignRequest(requestId: Long, maintenanceId: Long, adminId: Long, note: String): Boolean {
        val req = getRequest(requestId) ?: return false
        if (req.status == Status.COMPLETED) return false
        val staff = getUser(maintenanceId) ?: return false
        val db = writableDatabase
        val now = System.currentTimeMillis()
        db.beginTransaction()
        try {
            val cv = ContentValues()
            cv.put("assigned_to", maintenanceId)
            cv.put("status", Status.ASSIGNED)
            cv.put("updated_at", now)
            db.update("requests", cv, "id = ?", arrayOf(requestId.toString()))
            insertAssignment(db, requestId, maintenanceId, adminId, now)
            val remarks = if (note.isBlank()) "Assigned to ${staff.name}" else "Assigned to ${staff.name}. Note: ${note.trim()}"
            insertStatus(db, requestId, Status.ASSIGNED, remarks, adminId, now)
            db.setTransactionSuccessful()
            return true
        } finally {
            db.endTransaction()
        }
    }

    /** Maintenance staff changes the status and/or leaves remarks. */
    fun updateStatus(requestId: Long, status: String, remarks: String, userId: Long): Boolean {
        val req = getRequest(requestId) ?: return false
        if (req.status == Status.COMPLETED) return false
        val db = writableDatabase
        val now = System.currentTimeMillis()
        db.beginTransaction()
        try {
            val cv = ContentValues()
            cv.put("status", status)
            cv.put("updated_at", now)
            db.update("requests", cv, "id = ?", arrayOf(requestId.toString()))
            insertStatus(db, requestId, status, remarks.trim(), userId, now)
            db.setTransactionSuccessful()
            return true
        } finally {
            db.endTransaction()
        }
    }

    fun getHistory(requestId: Long): List<StatusUpdate> {
        val list = ArrayList<StatusUpdate>()
        readableDatabase.rawQuery(
            "SELECT s.id, s.request_id, s.status, s.remarks, COALESCE(u.name, 'System'), s.created_at " +
                "FROM status_updates s LEFT JOIN users u ON u.id = s.updated_by " +
                "WHERE s.request_id = ? ORDER BY s.created_at DESC, s.id DESC",
            arrayOf(requestId.toString())
        ).use { c ->
            while (c.moveToNext()) {
                list.add(StatusUpdate(c.getLong(0), c.getLong(1), c.getString(2), c.getString(3), c.getString(4), c.getLong(5)))
            }
        }
        return list
    }

    // ------------------------------------------------------------ announcements

    fun getAnnouncements(limit: Int = 0): List<Announcement> {
        val list = ArrayList<Announcement>()
        var sql = "SELECT a.id, a.title, a.message, COALESCE(u.name, 'Admin'), a.created_at " +
            "FROM announcements a LEFT JOIN users u ON u.id = a.posted_by " +
            "ORDER BY a.created_at DESC, a.id DESC"
        if (limit > 0) sql += " LIMIT $limit"
        readableDatabase.rawQuery(sql, null).use { c ->
            while (c.moveToNext()) {
                list.add(Announcement(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getLong(4)))
            }
        }
        return list
    }

    fun addAnnouncement(title: String, message: String, adminId: Long) {
        insertAnnouncement(writableDatabase, title.trim(), message.trim(), adminId, System.currentTimeMillis())
    }

    // ------------------------------------------------------------------ helpers

    private fun scalar(sql: String, args: Array<String>?): Int {
        readableDatabase.rawQuery(sql, args).use { c -> return if (c.moveToFirst()) c.getInt(0) else 0 }
    }
}
