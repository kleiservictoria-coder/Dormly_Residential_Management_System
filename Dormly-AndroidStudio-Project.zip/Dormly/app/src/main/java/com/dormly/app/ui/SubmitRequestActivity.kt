package com.dormly.app.ui

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import com.dormly.app.R
import com.dormly.app.data.Options
import com.dormly.app.data.Role
import com.dormly.app.util.bind

/** Resident form for submitting a new maintenance request. */
class SubmitRequestActivity : BaseActivity() {

    override val allowedRoles = arrayOf(Role.RESIDENT)

    private lateinit var etTitle: EditText
    private lateinit var etDescription: EditText
    private lateinit var spCategory: Spinner
    private lateinit var spPriority: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!authorized) return
        setContentView(R.layout.activity_submit_request)
        setupToolbar("New Maintenance Request")

        etTitle = bind(R.id.etTitle)
        etDescription = bind(R.id.etDescription)
        spCategory = bind(R.id.spCategory)
        spPriority = bind(R.id.spPriority)

        spCategory.adapter = spinnerAdapter(Options.CATEGORIES)
        spPriority.adapter = spinnerAdapter(Options.PRIORITIES)
        spPriority.setSelection(1) // Medium

        bind<Button>(R.id.btnSubmit).setOnClickListener { submit() }
    }

    override fun onResume() {
        super.onResume()
        if (!authorized) return
        if (!refreshUser()) return
        bind<TextView>(R.id.txtUnitInfo).text =
            if (user.unitNumber != null) "Reporting for Unit ${user.unitNumber} \u00B7 Floor ${user.floor}"
            else "You have no unit assigned yet"
    }

    private fun spinnerAdapter(items: List<String>) =
        ArrayAdapter(this, android.R.layout.simple_spinner_item, items).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

    private fun submit() {
        val title = etTitle.text.toString().trim()
        val description = etDescription.text.toString().trim()

        if (title.length < 3) {
            etTitle.error = "Enter a short title (at least 3 characters)"
            etTitle.requestFocus()
            return
        }
        if (description.length < 10) {
            etDescription.error = "Please describe the problem (at least 10 characters)"
            etDescription.requestFocus()
            return
        }
        val category = Options.CATEGORIES[spCategory.selectedItemPosition]
        val priority = Options.PRIORITIES[spPriority.selectedItemPosition]
        val id = db.createRequest(user, title, description, category, priority)
        toast("Request #$id submitted")
        finish()
    }
}
