# Dormly – Residential Management App (Android, Kotlin, XML, SQLite)

Dormly connects a building's **Admin**, **Residents** and **Maintenance Personnel** through one local SQLite database.
Lab Act 3 deliverable: dashboard front-end + working features, manifest, `MainActivity`, layouts.

## Open & run
1. Android Studio (Koala or newer, bundled JDK 17+) → **File ▸ Open** → select the `Dormly` folder.
2. Let Gradle sync (internet needed once; Gradle 8.7 / AGP 8.5.2 / Kotlin 1.9.24 are downloaded automatically).
3. Pick an emulator or phone (Android 7.0 / API 24+) and press **Run ▶**.
4. To build an APK: **Build ▸ Build Bundle(s) / APK(s) ▸ Build APK(s)** → `app/build/outputs/apk/debug/app-debug.apk`.

No third-party libraries: only the Android framework + Kotlin stdlib.

## Demo accounts (password for all: `dormly123`)
| Role | Email |
|---|---|
| Building Admin | admin@dormly.com |
| Resident (Unit 101) | resident@dormly.com |
| Maintenance | maintenance@dormly.com |

Extra seed users: maria@dormly.com, paolo@dormly.com (residents), ana@dormly.com (maintenance). The login screen has quick-fill buttons.

## Try the main workflow
1. Log in as **resident** → *Report a maintenance issue* → fill title / category / priority / description → Submit.
2. Log out → **admin** → the request is under *Needs your attention* → open it → choose staff → *Assign request*.
3. Log out → **maintenance** → open the task → set *In Progress* / *Completed* with remarks → *Save update*.
4. Log in as resident or admin again → status and the full history timeline are updated.

## Features by role
- **Admin:** dashboard stats, all requests + filters, request history, assign/reassign, manage residents & maintenance staff (add/edit/remove), manage housing units, post announcements.
- **Resident:** dashboard (unit, open/resolved counts, active requests, latest announcements), submit requests, own requests with status filters, request history, announcements.
- **Maintenance:** dashboard (to do / in progress / completed), assigned requests, details, update status (Assigned / In Progress / Completed), remarks (required when completing), announcements.

## Project structure
```
app/src/main/
  AndroidManifest.xml            launcher = MainActivity; 10 more activities registered
  java/com/dormly/app/
    MainActivity.kt              splash -> routes to Login or role dashboard
    data/  Models.kt  DormlyDb.kt    SQLite schema, seed data, all queries
    util/  Session.kt Nav.kt UiUtil.kt SimpleAdapter.kt
    ui/    Login / Admin|Resident|MaintenanceDashboard / RequestList / RequestDetail /
           SubmitRequest / Announcements / Residents / Units activities + BaseActivity
  res/layout, drawable, values, mipmap-*   XML layouts, icons, colors, themes
```
Database `dormly.db` tables: `users, units, requests, assignments, status_updates, announcements`.
Data persists across app restarts. Passwords are stored as salted SHA-256 hashes. To reset the data: clear the app's storage.

## Design
Role-colored themes (indigo = admin, teal = resident, orange = maintenance), card-based layout, consistent buttons and inputs, color-coded status chips (Pending amber, Assigned blue, In Progress purple, Completed green).

## Build notes
`tools/build_apk_manual.sh` is the command-line script (aapt + kotlinc + dx + apksigner) used to produce the bundled debug APK in an environment without the Android SDK/Gradle repositories. Normal use: Android Studio / `./gradlew assembleDebug`.
